dojo.declare("classes.KGConfig", null, {
    statics: {
        disableWebWorkers: false,
        locales: ["ru", "ja", "br", "es", "fr", "cz", "zh", "zht", "pl", "de"],
        schemes: ["dark", "grassy", "sleek", "black", "wood", "bluish", "grayish", "greenish", "tombstone", "spooky", "gold", "space", "school", "fluid", "vessel", "minimalist", "oil", "unicorn", "anthracite", "chocolate", "vintage", "computer", "arctic", "cyber", "factory", "catnip", "dune"],
        notations: ["si", "e", "sie"]
    }
});
